<x-pie-chart id="task-chart"

             :labels="$chart['labels']"

             :values="$chart['chart_data']"

             :colors="$chart['colors']"

             height="250" width="300"/>
