<?php

namespace Modules\Recruit\Http\Requests\FooterLinks;

use App\Http\Requests\CoreRequest;

class StoreFooterLinks extends CoreRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title' => 'required',
            'slug' => 'required|unique:recruit_footer_links,slug',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
}
