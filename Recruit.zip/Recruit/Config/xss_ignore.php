<?php

return [
    'job_description',
    'meta_description',
    'cover_letter',
    'candidate_comment',
    'remark',
    'reason',
    'about',
];
