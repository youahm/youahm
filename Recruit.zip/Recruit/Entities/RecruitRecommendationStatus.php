<?php

namespace Modules\Recruit\Entities;

use App\Models\BaseModel;
use App\Traits\HasCompany;

class RecruitRecommendationStatus extends BaseModel
{
    use HasCompany;
}
