<?php

namespace Modules\Recruit\Entities;

use App\Models\BaseModel;

class RecruitJobOfferQuestion extends BaseModel
{
    protected $fillable = [];

    protected $table = 'recruit_job_offer_questions';
}
