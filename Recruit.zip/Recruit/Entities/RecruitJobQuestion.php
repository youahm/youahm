<?php

namespace Modules\Recruit\Entities;

use App\Models\BaseModel;

class RecruitJobQuestion extends BaseModel
{
    protected $fillable = [];
}
